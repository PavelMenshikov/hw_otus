## Домашнее задание №12 «Утилита для анализа лог-файлов»

### Чек-лист студента ([Что это?](https://github.com/OtusGolang/home_work/wiki/%D0%9A%D0%BE%D0%BC%D0%BC%D0%B5%D0%BD%D1%82%D0%B0%D1%80%D0%B8%D0%B8-%D0%BA-%D1%87%D0%B5%D0%BA-%D0%BB%D0%B8%D1%81%D1%82%D1%83-%D1%81%D1%82%D1%83%D0%B4%D0%B5%D0%BD%D1%82%D0%B0))
- [ ] Я перечитал задание после решения. [Зачем перечитывать задание?](https://github.com/OtusGolang/home_work/wiki/%D0%9A%D0%BE%D0%BC%D0%BC%D0%B5%D0%BD%D1%82%D0%B0%D1%80%D0%B8%D0%B8-%D0%BA-%D1%87%D0%B5%D0%BA-%D0%BB%D0%B8%D1%81%D1%82%D1%83-%D1%81%D1%82%D1%83%D0%B4%D0%B5%D0%BD%D1%82%D0%B0#user-content-%D0%97%D0%B0%D1%87%D0%B5%D0%BC-%D0%BF%D0%B5%D1%80%D0%B5%D1%87%D0%B8%D1%82%D1%8B%D0%B2%D0%B0%D1%82%D1%8C-%D0%B7%D0%B0%D0%B4%D0%B0%D0%BD%D0%B8%D0%B5)
- [ ] Я запустил `go mod tidy`.
- [ ] Я сравнил объем кода с объемом авторского решения. [Зачем сверять объем кода?](https://github.com/OtusGolang/home_work/wiki/%D0%9A%D0%BE%D0%BC%D0%BC%D0%B5%D0%BD%D1%82%D0%B0%D1%80%D0%B8%D0%B8-%D0%BA-%D1%87%D0%B5%D0%BA-%D0%BB%D0%B8%D1%81%D1%82%D1%83-%D1%81%D1%82%D1%83%D0%B4%D0%B5%D0%BD%D1%82%D0%B0#user-content-%D0%97%D0%B0%D1%87%D0%B5%D0%BC-%D1%81%D0%B2%D0%B5%D1%80%D1%8F%D1%82%D1%8C-%D0%BE%D0%B1%D1%8A%D0%B5%D0%BC-%D0%BA%D0%BE%D0%B4%D0%B0)
  - main.go ~100 строк

### Критерии оценки
- [ ] Пайплайн зелёный - 4 балла
- [ ] Понятность и чистота кода - до 2 баллов

#### Зачёт от 4 баллов
